import 'package:flutter/material.dart';
import 'package:sampleproject/Screens/Welcome/components/body.dart';
import 'package:sampleproject/Screens/Welcome/SignUp/ComponentSignUp/bodySignUp.dart';

class SignUpScreen extends StatelessWidget {
  @override
  Widget build(Build Context context) {
    return Scaffold(
      body: Body(
        child: Column(),
      ),
    );
  }
}

