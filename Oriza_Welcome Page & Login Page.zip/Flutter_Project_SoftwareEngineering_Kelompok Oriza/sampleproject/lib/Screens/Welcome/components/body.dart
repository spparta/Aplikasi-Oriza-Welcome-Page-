import 'dart:html';

import 'package:flutter/material.dart';
import 'package:sampleproject/Screens/Welcome/Login/Login_screen.dart';
import 'package:sampleproject/Screens/Welcome/components/background.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sampleproject/constants.dart';
import 'package:sampleproject/components/rounded_button.dart';
import 'package:sampleproject/Screens/Welcome/SignUp/sign_up_screen.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // Ukuran total pada tinggi & lebar screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <widget>[
            Text(
              "WELCOME TO ORIZA",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: size.height * 0.03),
            SvgPicture.asset(
              "sampleproject\assets\icon\oriza.svg",
              height: size.height * 0.45,
            ),
            SizedBox(height: size.height * 0.05),
            RoundedButton(
              text: "LOGIN",
              press: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return LoginScreen();
                    },
                  ),
                );
              },
            ),
            RoundedButton(
              text: "SIGN UP",
              color: kPrimaryLightColor,
              textColor: Colors.black,
              press: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return SignUpScreen();
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
