import 'package:flutter/material.dart';
import "package:sampleproject/Screens/Welcome/Login/ComponentLogin/bodyLogin.dart"

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    ); //Scaffold
  }
}

