import 'package:flutter/material.dart';

const kPrimaryColor = Color.fromARGB(255, 28, 193, 56);
const kPrimaryLightColor = Color(0xFF1E6FF);
