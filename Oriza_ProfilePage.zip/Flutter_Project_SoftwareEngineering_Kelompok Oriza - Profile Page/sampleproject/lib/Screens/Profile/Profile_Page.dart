import 'dart:html';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:sampleproject/Screens/Profile/enums.dart';
import 'component/body.dart';
import 'package:sampleproject/Screens/Profile/component/custom_bottom_nav_bar.dart';

class ProfileScreen extends StatelessWidget {
  static String routeName = '/profile';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Profile"),
      ),
      body: Body(),
      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.Profile),
    );
  }
}
