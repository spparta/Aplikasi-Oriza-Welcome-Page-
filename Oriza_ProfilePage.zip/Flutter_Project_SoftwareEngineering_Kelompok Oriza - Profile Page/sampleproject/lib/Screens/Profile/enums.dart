enum MenuState { Home, Search, Library, Profile }
