import 'dart:html';
import 'package:flutter/material.dart';
import 'profile_pic.dart';
import 'profile_menu.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ProfilePic(),
        SizedBox(height: 20),
        ProfileMenu(
          icon: "sampleproject\assets\icon\Setting.svg",
          text: "Account Settings",
          press: () {},
        ),
        ProfileMenu(
          icon: "sampleproject\assets\icon\Address.svg",
          text: "Address Settings",
          press: () {},
        ),
        ProfileMenu(
          icon: "sampleproject\assets\icon\Privacy & Policy.svg",
          text: "Privacy & Policy",
          press: () {},
        ),
        ProfileMenu(
          icon: "sampleproject\assets\icon\Contact.svg",
          text: "Contact Us",
          press: () {},
        ),
        ProfileMenu(
          icon: "sampleproject\assets\icon\Log Out.svg",
          text: "Log Out",
          press: () {},
        ),
      ],
    );
  }
}
