import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../enums.dart';
import 'package:sampleproject/Screens/Profile/Profile_Page.dart';

class CustomBottomNavrBar extends StatelessWidget{
    const CustomBottomNavrBar({
      Key key,
      @required this.selectedMenu,
}) :super(key: key);

  final MenuState selectedMenu;

  @override
    Widget build(BuildContext context){
        final Color inActiveIconColor = Color(0xFFB6B6B6);
        return Container(
        padding: EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(40),
            topRight: Radius.circular(40),
          ),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, -15),
              blurRadius: 20,
              color: Color(0xFFDADADA).withOpacity(0.15),
            ),
          ],
        ),
        child: SafeArea(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(
                icon: SvgPicture.asset(
                    "sampleproject\assets\icon\Home_Icons.svg", 
                    color: MenuState.Home == selectedMenu 
                    ? kPrimaryColor
                    : inActiveIconColor,
                    ),
                onPressed: () => 
                  Navigator.pushNamed(context, HomeScreen.routeName),
              ),
              IconButton(
                icon: SvgPicture.asset(
                    "sampleproject\assets\icon\Search_Icon.svg",
                    color: MenuState.Search == selectedMenu 
                    ? kPrimaryColor
                    : inActiveIconColor,
                    ),
                onPressed: () {},
              ),
              IconButton(
                icon: SvgPicture.asset(
                    "sampleproject\assets\icon\Library_icon.svg",
                    color: MenuState.Library == selectedMenu 
                    ? kPrimaryColor
                    : inActiveIconColor,
                    ),
                onPressed: () {},
              ),
              IconButton(
                icon: SvgPicture.asset(
                    "sampleproject\assets\icon\mini_profile_icon.svg",
                    color: MenuState.Profile == selectedMenu 
                    ? kPrimaryColor
                    : inActiveIconColor,
                    ),
                onPressed: () => 
                  Navigator.pushNamed(context, ProfileScreen.routeName),
              ),
            ],
          ),
        ),
      ),
    };
  }
