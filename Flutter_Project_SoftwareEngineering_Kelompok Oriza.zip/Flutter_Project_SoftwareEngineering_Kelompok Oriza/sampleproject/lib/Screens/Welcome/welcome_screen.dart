import 'package:flutter/material.dart';

class WelcomeScreen extends StatelessWidget {
  @HttpOverrides //diperbaiki
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
