import 'dart:html';
import 'dart:ui';

import 'package:flutter/material.dart';

class SearchProducts extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Search App"),
        actions: <Widget>[
          IconButton(
              icon: Icon(Icons.search),
              onPressed: () {
                showSearch(context: context, delegate: DataSearch());
              })
        ],
      ),
      drawer: Drawer(),
    );
  }
}

class DataSearch extends SearchDelegate<String> {
  final Products = [
    "GREEN MAGIC - Kemasan Spray 200ml",
    "Pembasmi kutu putih dan jamur tanaman",
    "Pupuk cair aglonema SUPER BIO AGLONEMA",
    "PUPUK CAIR TANAMAN HIAS DAUN 500ml",
    "Pupuk kalsium nitrat karate plus boroni",
    "Pupuk organik cair tanaman hias GDM",
    "Pupuk Merah Aglonema SK Cote",
    "Pupuk organik vermicompost premium",
    "BMS KASCING Vermicompost Pupuk-Kompos Tanaman Hias 5kg",
    "VILDAPEL",
    "PAPAJA",
    "NYPON",
    "MUSKOTBLOMMA",
    "GRADVIS",
    "GALIAMELON",
    "FRIDFULL",
    "CITRUSFRUKT",
    "CHIAFRON",
    "CASHEWAPPLE",
    "BOYSENBAR",
    "Petunia",
    "Lidah Mertua",
    "Lavender",
    "Kuping Gajah",
    "Kaktus Natal",
    "Kaktus Anggur",
    "Gelombang Cinta",
    "Ekor Tupai",
    "Clivia",
    "Bunga Matahari",
    "Begonia",
    "Asoka Putih",
    "Amarilis",
    "Aglonema"
  ];

  final recentProducts = [];

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
          icon: Icon(Icons.clear),
          onPressed: () {
            query = "";
          })
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
        icon: AnimatedIcon(
          icon: AnimatedIcons.menu_arrow,
          progress: transitionAnimation,
        ),
        onPressed: () {
          close(context, null);
        });
  }

  @override
  Widget buildResults(BuildContext context) {
    return Container(
      height: 100.0,
      width: 100.0,
      child: Card(
        color: Colors.red,
        child: Center(
          child: Text(query),
        ),
      ),
    );
  }

  @override
  Widget buildSugesstions(BuildContext context) {
    final sugesstionList = query.isEmpty
        ? recentProducts
        : Products.where((p) => p.startsWith(query)).toList();

    return ListView.builder(
      itemBuilder: (context, index) => ListTile(
        onTap: () {
          showResults(context);
        },
        leading: Icon(Icons.location_product),
        title: RichText(
          text: TextSpan(
              text: sugesstionList[index].substring(0, query.length),
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
              children: [
                TextSpan(
                    text: sugesstionList[index].substring(query.length),
                    style: TextStyle(color: Colors.grey))
              ]),
        ),
      ),
      itemCount: sugesstionList.length,
    );
  }
}
